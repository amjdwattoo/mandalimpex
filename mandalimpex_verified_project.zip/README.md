# MANDALIMPEX Full Project

This contains the mobile app, backend API, and admin panel.