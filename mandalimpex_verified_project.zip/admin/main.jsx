import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => <h1>MANDALIMPEX Admin Panel</h1>;

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
